-- DYNAMIC DATA MASKING (DDM)
-- CREAR BASE DE EJEMPLO Yellow2

DROP DATABASE IF EXISTS Yellow2
GO
CREATE DATABASE Yellow2;
GO
USE Yellow2
GO

DROP TABLE IF EXISTS Eventos
GO

-- (2) Crear tabla Eventos
CREATE TABLE dbo.Eventos(
    EventoID int IDENTITY(1,1) NOT NULL PRIMARY KEY,
	Fecha date NULL,
	Cliente varchar(50) NULL,
	Tipo_evento varchar(200) NULL,
	Duraci�n varchar(50) NULL,
	TotalFacturado decimal(10,2) NULL,
)
GO

SET IDENTITY_INSERT dbo.Eventos ON
-- Permite insertar valores expl�citos en la columna identidad de una tabla.

INSERT INTO [dbo].[Eventos] ([EventoID], [Fecha], [Cliente],[Tipo_evento], [Duraci�n], [TotalFacturado]) VALUES (1, N'2019-05-01', N'Louzao', N'Presentaci�n Nuevo Clase A', N'4 horas', CAST(300.00 AS Decimal(10, 2)))
INSERT INTO [dbo].[Eventos] ([EventoID], [Fecha], [Cliente],[Tipo_evento], [Duraci�n], [TotalFacturado]) VALUES (2, N'2019-05-02', N'Hijos de Rivera',N'Concurso Hamburguesas', N'Fin de semana', CAST(300.00 AS Decimal(10, 2)))
INSERT INTO [dbo].[Eventos] ([EventoID], [Fecha], [Cliente],[Tipo_evento], [Duraci�n], [TotalFacturado]) VALUES (3, N'2019-05-02', N'Los40',N'Entrevista',N'1 hora', CAST(150.00 AS Decimal(10, 2)))
INSERT INTO [dbo].[Eventos] ([EventoID], [Fecha], [Cliente],[Tipo_evento], [Duraci�n], [TotalFacturado]) VALUES (4, N'2019-05-03', N'Joma',N'Sesi�n fotos cat�logo', N'4 horas', CAST(550.00 AS Decimal(10, 2)))
INSERT INTO [dbo].[Eventos] ([EventoID], [Fecha], [Cliente],[Tipo_evento], [Duraci�n], [TotalFacturado]) VALUES (5, N'2019-05-05', N'Nike', N'Sesi�n fotos cat�logo y presentaci�n de producto', N'Todo el d�a', CAST(700.00 AS Decimal(10, 2)))
INSERT INTO [dbo].[Eventos] ([EventoID], [Fecha], [Cliente],[Tipo_evento], [Duraci�n], [TotalFacturado]) VALUES (6, N'2019-05-10', N'Bamb�',N'Casting serie Netlix', N'4 horas', CAST(200.00 AS Decimal(10, 2)))
INSERT INTO [dbo].[Eventos] ([EventoID], [Fecha], [Cliente],[Tipo_evento], [Duraci�n], [TotalFacturado]) VALUES (7, N'2019-05-12', N'Vaca Films',N'Casting pel�cula', N'4 horas', CAST(200.00 AS Decimal(10, 2)))
INSERT INTO [dbo].[Eventos] ([EventoID], [Fecha], [Cliente],[Tipo_evento], [Duraci�n], [TotalFacturado]) VALUES (8, N'2019-05-13', N'Galcar',N'Recoger Honda E para campa�a Instagram', N'Recogida m�s 48h', CAST(450.00 AS Decimal(10, 2)))
INSERT INTO [dbo].[Eventos] ([EventoID], [Fecha], [Cliente],[Tipo_evento], [Duraci�n], [TotalFacturado]) VALUES (9, N'2019-05-20', N'La Voz De Galicia',N'Entrevista', N'1 hora', CAST(150.00 AS Decimal(10, 2)))
INSERT INTO [dbo].[Eventos] ([EventoID], [Fecha], [Cliente],[Tipo_evento], [Duraci�n], [TotalFacturado]) VALUES (10, N'2019-05-25', N'Leche R�o',N'Presentaci�n patrocinador', N'3 horas', CAST(400.00 AS Decimal(10, 2)))
SET IDENTITY_INSERT [dbo].[Eventos] OFF
GO
--- END POPULATE

SELECT * FROM Eventos
GO

-- EventoID	Fecha	Cliente	Tipo_evento	Duraci�n	TotalFacturado
--1	2019-05-01	Louzao	Presentaci�n Nuevo Clase A	4 horas	300.00
--2	2019-05-02	Hijos de Rivera	Concurso Hamburguesas	Fin de semana	300.00
--3	2019-05-02	Los40	Entrevista	1 hora	150.00
--4	2019-05-03	Joma	Sesi�n fotos cat�logo	4 horas	550.00
--5	2019-05-05	Nike	Sesi�n fotos cat�logo y presentaci�n de producto	Todo el d�a	700.00
--6	2019-05-10	Bamb�	Casting serie Netlix	4 horas	200.00
--7	2019-05-12	Vaca Films	Casting pel�cula	4 horas	200.00
--8	2019-05-13	Galcar	Recoger Honda E para campa�a Instagram	Recogida m�s 48h	450.00
--9	2019-05-20	La Voz De Galicia	Entrevista	1 hora	150.00
--10	2019-05-25	Leche R�o	Presentaci�n patrocinador	3 horas	400.00


SELECT
   s.EventoID,
   s.Fecha,
   s.Cliente,
   s.Tipo_evento,
   s.Duraci�n,
   s.TotalFacturado
FROM dbo.Eventos s
GO


-- creamos otro usuario y le damos permisos

DROP USER IF EXISTS YHuser
GO
CREATE USER YHuser WITHOUT LOGIN;
GO
GRANT SELECT ON Eventos TO YHuser;
GO

-- Stored procedure to check dynamic data masking status
CREATE OR ALTER PROC ShowMaskingStatus
AS
BEGIN
          SET NOCOUNT ON
		  SELECT c.name, tb1.name as table_name, c.is_masked, c.masking_function
		  FROM sys.masked_columns AS c
		  JOIN sys.tables AS tb1
		        ON c.object_id = tb1.object_id
		  WHERE is_masked = 1;
END
GO

EXEC ShowMaskingStatus
GO
-- name	table_name	is_masked	masking_function


ALTER TABLE Eventos
       ALTER COLUMN Tipo_evento varchar (200) MASKED WITH (FUNCTION = 'default()');
GO

EXEC ShowMaskingStatus
GO

--name	  table_name    	is_masked	masking_function
--Tipo_evento	  Eventos	    1	       default()

-- Execute SELECT as YHuser
EXECUTE AS USER = 'YHuser';
GO

-- ver Eventos
SELECT
   s.EventoID,
   s.Fecha,
   s.Cliente,
   s.Tipo_evento,
   s.Duraci�n,
   s.TotalFacturado
FROM dbo.Eventos s
GO

--EventoID	Fecha	Cliente	Tipo_evento	Duraci�n	TotalFacturado
--1	2019-05-01	Louzao	xxxx	4 horas	300.00
--2	2019-05-02	Hijos de Rivera	xxxx	Fin de semana	300.00
--3	2019-05-02	Los40	xxxx	1 hora	150.00
--4	2019-05-03	Joma	xxxx	4 horas	550.00
--5	2019-05-05	Nike	xxxx	Todo el d�a	700.00
--6	2019-05-10	Bamb�	xxxx	4 horas	200.00
--7	2019-05-12	Vaca Films	xxxx	4 horas	200.00
--8	2019-05-13	Galcar	xxxx	Recogida m�s 48h	450.00
--9	2019-05-20	La Voz De Galicia	xxxx	1 hora	150.00
--10	2019-05-25	Leche R�o	xxxx	3 horas	400.00


REVERT
GO

PRINT USER
GO

--dbo

--Completion time: 2023-02-27T20:50:28.5672995+01:00

-- view Eventos

SELECT
   s.EventoID,
   s.Fecha,
   s.Cliente,
   s.Tipo_evento,
   s.Duraci�n,
   s.TotalFacturado
FROM dbo.Eventos s
GO

-- EventoID	Fecha	Cliente	Tipo_evento	Duraci�n	TotalFacturado
--1	2019-05-01	Louzao	Presentaci�n Nuevo Clase A	4 horas	300.00
--2	2019-05-02	Hijos de Rivera	Concurso Hamburguesas	Fin de semana	300.00
--3	2019-05-02	Los40	Entrevista	1 hora	150.00
--4	2019-05-03	Joma	Sesi�n fotos cat�logo	4 horas	550.00
--5	2019-05-05	Nike	Sesi�n fotos cat�logo y presentaci�n de producto	Todo el d�a	700.00
--6	2019-05-10	Bamb�	Casting serie Netlix	4 horas	200.00
--7	2019-05-12	Vaca Films	Casting pel�cula	4 horas	200.00
--8	2019-05-13	Galcar	Recoger Honda E para campa�a Instagram	Recogida m�s 48h	450.00
--9	2019-05-20	La Voz De Galicia	Entrevista	1 hora	150.00
--10	2019-05-25	Leche R�o	Presentaci�n patrocinador	3 horas	400.00

-- Partial masking nombres de clientes

ALTER TABLE Eventos
        ALTER COLUMN Cliente ADD MASKED WITH (FUNCTION = 'partial(1,"xxxxxxx",0)')
GO
--Commands completed successfully.

--Completion time: 2023-02-27T20:55:06.1453622+01:00

EXEC ShowMaskingStatus
GO

--name	     table_name	     is_masked	masking_function
--Cliente	Eventos	     1	    partial(1, "xxxxxxx", 0)
--Tipo_evento	    Eventos	     1	    default()


-- PROBAMOS DE NUEVO CON EL USUARIO YHuser

EXECUTE AS USER = 'YHuser';
GO

-- ver Eventos
SELECT
   s.EventoID,
   s.Fecha,
   s.Cliente,
   s.Tipo_evento,
   s.Duraci�n,
   s.TotalFacturado
FROM dbo.Eventos s
GO

--EventoID	Fecha	Cliente	Tipo_evento	Duraci�n	TotalFacturado
--1	2019-05-01	Lxxxxxxx	xxxx	4 horas	300.00
--2	2019-05-02	Hxxxxxxx	xxxx	Fin de semana	300.00
--3	2019-05-02	Lxxxxxxx	xxxx	1 hora	150.00
--4	2019-05-03	Jxxxxxxx	xxxx	4 horas	550.00
--5	2019-05-05	Nxxxxxxx	xxxx	Todo el d�a	700.00
--6	2019-05-10	Bxxxxxxx	xxxx	4 horas	200.00
--7	2019-05-12	Vxxxxxxx	xxxx	4 horas	200.00
--8	2019-05-13	Gxxxxxxx	xxxx	Recogida m�s 48h	450.00
--9	2019-05-20	Lxxxxxxx	xxxx	1 hora	150.00
--10	2019-05-25	Lxxxxxxx	xxxx	3 horas	400.00

REVERT
GO

PRINT USER
GO

--dbo

--Completion time: 2023-02-27T20:50:28.5672995+01:00

-- view Eventos

SELECT
   s.EventoID,
   s.Fecha,
   s.Cliente,
   s.Tipo_evento,
   s.Duraci�n,
   s.TotalFacturado
FROM dbo.Eventos s
GO

-- DBO (y los que tengan permisos de dbo) ven todo

-- RANDOM SYNAMIC DATA MASKING OF TotalFacturado column

ALTER TABLE Eventos
       ALTER COLUMN TotalFacturado decimal(10,2) MASKED WITH (FUNCTION = 'random(1,12)')
GO

EXEC ShowMaskingStatus
GO

--name	        table_name	    is_masked	masking_function
--Cliente	    Eventos	     1	    partial(1, "xxxxxxx", 0)
--Tipo_evento	        Eventos	     1   	default()
--TotalFacturado	Eventos	     1  	random(1.00, 12.00)

EXECUTE AS USER = 'YHuser';
GO

-- ver Eventos
SELECT
   s.EventoID,
   s.Fecha,
   s.Cliente,
   s.Tipo_evento,
   s.Duraci�n,
   s.TotalFacturado
FROM dbo.Eventos s
GO


--EventoID	Fecha	Cliente	Tipo_evento	Duraci�n	TotalFacturado
1	2019-05-01	Lxxxxxxx	xxxx	4 horas	8.53
2	2019-05-02	Hxxxxxxx	xxxx	Fin de semana	8.28
3	2019-05-02	Lxxxxxxx	xxxx	1 hora	8.41
4	2019-05-03	Jxxxxxxx	xxxx	4 horas	2.30
5	2019-05-05	Nxxxxxxx	xxxx	Todo el d�a	10.97
6	2019-05-10	Bxxxxxxx	xxxx	4 horas	2.49
7	2019-05-12	Vxxxxxxx	xxxx	4 horas	1.19
8	2019-05-13	Gxxxxxxx	xxxx	Recogida m�s 48h	11.81
9	2019-05-20	Lxxxxxxx	xxxx	1 hora	8.40
10	2019-05-25	Lxxxxxxx	xxxx	3 horas	11.46


REVERT
GO

PRINT USER
GO

--dbo

-- view Eventos

SELECT
   s.EventoID,
   s.Fecha,
   s.Cliente,
   s.Tipo_evento,
   s.Duraci�n,
   s.TotalFacturado
FROM dbo.Eventos s
GO

ALTER TABLE Eventos
       ALTER COLUMN Duraci�n ADD MASKED WITH (FUNCTION = 'partial(1,"---",1)')
GO

EXEC ShowMaskingStatus
GO

EXECUTE AS USER = 'YHuser';
GO

-- ver Eventos
SELECT
   s.EventoID,
   s.Fecha,
   s.Cliente,
   s.Tipo_evento,
   s.Duraci�n,
   s.TotalFacturado
FROM dbo.Eventos s
GO

--EventoID	Fecha	Cliente	Tipo_evento	Duraci�n	TotalFacturado
--1	2019-05-01	Lxxxxxxx	xxxx	4---s	3.38
--2	2019-05-02	Hxxxxxxx	xxxx	F---a	3.64
--3	2019-05-02	Lxxxxxxx	xxxx	1---a	11.41
--4	2019-05-03	Jxxxxxxx	xxxx	4---s	9.08
--5	2019-05-05	Nxxxxxxx	xxxx	T---a	8.44
--6	2019-05-10	Bxxxxxxx	xxxx	4---s	5.79
--7	2019-05-12	Vxxxxxxx	xxxx	4---s	11.55
--8	2019-05-13	Gxxxxxxx	xxxx	R---h	7.66
--9	2019-05-20	Lxxxxxxx	xxxx	1---a	3.28
--10	2019-05-25	Lxxxxxxx	xxxx	3---s	11.89

REVERT
GO

-- PARA OTORGAR PERMISOS AL USUARIO YHuser

GRANT UNMASK TO YHuser
GO

-- Exectute SELECT AS YHuser

EXECUTE AS USER = 'YHuser';
GO

-- ver Eventos
SELECT
   s.EventoID,
   s.Fecha,
   s.Cliente,
   s.Tipo_evento,
   s.Duraci�n,
   s.TotalFacturado
FROM dbo.Eventos s
GO


-- COMPROBAMOS QUE FUNCIONA

--  EventoID	Fecha	Cliente	Tipo_evento	Duraci�n	TotalFacturado
--1	2019-05-01	Louzao	Presentaci�n Nuevo Clase A	4 horas	300.00
--2	2019-05-02	Hijos de Rivera	Concurso Hamburguesas	Fin de semana	300.00
--3	2019-05-02	Los40	Entrevista	1 hora	150.00
--4	2019-05-03	Joma	Sesi�n fotos cat�logo	4 horas	550.00
--5	2019-05-05	Nike	Sesi�n fotos cat�logo y presentaci�n de producto	Todo el d�a	700.00
--6	2019-05-10	Bamb�	Casting serie Netlix	4 horas	200.00
--7	2019-05-12	Vaca Films	Casting pel�cula	4 horas	200.00
--8	2019-05-13	Galcar	Recoger Honda E para campa�a Instagram	Recogida m�s 48h	450.00
--9	2019-05-20	La Voz De Galicia	Entrevista	1 hora	150.00
--10	2019-05-25	Leche R�o	Presentaci�n patrocinador	3 horas	400.00

REVERT
GO

-- DROPPING A DYNAMIC DATA MASK

ALTER TABLE Eventos
     ALTER COLUMN Tipo_evento DROP MASKED
GO

EXEC ShowMaskingStatus
GO

-- VEMOS QUE DESAPARECE EL ENMASCARADO DEL Tipo_evento

--name	table_name	is_masked	masking_function
--Cliente	Eventos	1	partial(1, "xxxxxxx", 0)
--Duraci�n	Eventos	1	partial(1, "---", 1)
--TotalFacturado	Eventos	1	random(1.00, 12.00)

REVOKE UNMASK FROM YHuser
GO

EXECUTE AS USER = 'YHuser';
GO

-- ver Eventos
SELECT
   s.EventoID,
   s.Fecha,
   s.Cliente,
   s.Tipo_evento,
   s.Duraci�n,
   s.TotalFacturado
FROM dbo.Eventos s
GO

-- VEMOS QUE SIGUE LO DEM�S ENMASCARADO

--1	2019-05-01	Lxxxxxxx	Presentaci�n Nuevo Clase A	4---s	3.75
--2	2019-05-02	Hxxxxxxx	Concurso Hamburguesas	F---a	3.89
--3	2019-05-02	Lxxxxxxx	Entrevista	1---a	11.37
--4	2019-05-03	Jxxxxxxx	Sesi�n fotos cat�logo	4---s	4.27
--5	2019-05-05	Nxxxxxxx	Sesi�n fotos cat�logo y presentaci�n de producto	T---a	9.93
--6	2019-05-10	Bxxxxxxx	Casting serie Netlix	4---s	6.37
--7	2019-05-12	Vxxxxxxx	Casting pel�cula	4---s	2.30
--8	2019-05-13	Gxxxxxxx	Recoger Honda E para campa�a Instagram	R---h	3.63
--9	2019-05-20	Lxxxxxxx	Entrevista	1---a	8.20
--10	2019-05-25	Lxxxxxxx	Presentaci�n patrocinador	3---s	9.03

REVERT
GO

SELECT s.EventoID,s.Duraci�n
FROM dbo.Eventos s
GO

