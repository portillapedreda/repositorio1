--Creo primero la base de datos con los Filegroup (todo en una misma sentencia). 
--Primero como siempre, controlando la existencia de la base de datos:

-- CREAMOS TABLA TIPO FILETABLE Y LA CONSULTAMOS:

USE [master]
GO

DROP DATABASE IF EXISTS yhprueba;
GO

CREATE DATABASE yhprueba
ON PRIMARY
(
    NAME = yhprueba_data,
    FILENAME = 'C:\pruebasyh\yhprueba.mdf',
    SIZE = 10MB,
    MAXSIZE = 100MB,
    FILEGROWTH = 5MB
),
FILEGROUP FileStreamFG CONTAINS FILESTREAM
(
    NAME = yhprueba_fs,
    FILENAME = 'C:\pruebasyh\yhprueba_fs'
)
LOG ON
(
    NAME = yhprueba_Log,
    FILENAME = 'C:\pruebasyh\yhprueba_Log.ldf',
    SIZE = 5MB,
    MAXSIZE = 50MB,
    FILEGROWTH = 1MB
)
GO

ALTER DATABASE yhprueba
SET FILESTREAM
(
    NON_TRANSACTED_ACCESS = FULL,
    DIRECTORY_NAME = 'yhprueba_fs'
)
GO

--CONSULTA

SELECT DB_NAME(database_id),
non_transacted_access,
non_transacted_access_desc
FROM sys.database_filestream_options;
GO
