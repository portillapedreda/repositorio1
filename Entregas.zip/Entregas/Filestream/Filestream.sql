EXEC sp_configure filestream_access_level, 2 
RECONFIGURE 
GO
--Se ha cambiado la opci�n de configuraci�n 'filestream access level' de 0 a 2. Ejecute la instrucci�n RECONFIGURE para instalar.
--El acceso de E/S de archivos de FILESTREAM no se ha podido habilitar. El administrador del sistema operativo debe habilitar el acceso de E/S de archivos de FILESTREAM en la instancia con el Administrador de configuraci�n.
--Hora de finalizaci�n: 2023-03-15T16:29:17.4686717+01:00

----- CREAMOS UN FILEGROUP PARA PODER METER TODO

USE MASTER 
GO

ALTER DATABASE YellowHouse 
	ADD FILEGROUP [YellowHouse_FILESTREAM]
CONTAINS FILESTREAM
GO

ALTER DATABASE YellowHouse
	ADD FILE (
		NAME = 'xrpp_FILESTREAM',
		FILENAME = 'C:\Backup\xrppfilestream'
	)
	TO FILEGROUP [YellowHouse_FILESTREAM]
GO


--ACTIVAMOS LA BASE DE DATOS

USE YellowHouse
GO

DROP TABLE IF EXISTS dbo.fotos

CREATE TABLE dbo.fotos (ID INT IDENTITY,
							NOMBRE varchar(255),
							CONTENIDO VARBINARY(MAX),
							EXTENSION CHAR(4)
)
GO

--INSERTAMOS FICHEROS DE IMAGENES


INSERT INTO dbo.fotos (NOMBRE,CONTENIDO,EXTENSION)
SELECT 'foto1', BULKCOLUMN,'JPEG'
FROM OPENROWSET (BULK N'C:\imagenesyh\foto1.jpg' , SINGLE_BLOB) AS DOCUMENT
GO

INSERT INTO dbo.fotos (NOMBRE,CONTENIDO,EXTENSION)
SELECT 'foto2', BULKCOLUMN,'JPEG'
FROM OPENROWSET (BULK N'C:\imagenesyh\foto2.jpg' , SINGLE_BLOB) AS DOCUMENT
GO


SELECT * FROM dbo.fotos
GO



--Para borrar la tabla, primero borramos la columna y desasociamos el filestream. Despu�s, podemos borrarla desde master:

ALTER TABLE dbo.fotos  DROP COLUMN CONTENIDO
GO


ALTER TABLE dbo.fotos SET (FILESTREAM_ON="NULL")
GO


ALTER DATABASE YellowHouse REMOVE FILE xrpp_FILESTREAM
GO

USE MASTER
GO