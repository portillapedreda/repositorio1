--Creo primero la base de datos con los Filegroup (todo en una misma sentencia). 
--Primero como siempre, controlando la existencia de la base de datos:

-- CREAMOS TABLA TIPO FILETABLE Y LA CONSULTAMOS:

USE [master]
GO

DROP DATABASE IF EXISTS yhprueba;
GO

CREATE DATABASE yhprueba
ON PRIMARY
(
    NAME = yhprueba_data,
    FILENAME = 'C:\pruebasyh\yhprueba.mdf',
    SIZE = 10MB,
    MAXSIZE = 100MB,
    FILEGROWTH = 5MB
),
FILEGROUP FileStreamFG CONTAINS FILESTREAM
(
    NAME = yhprueba_fs,
    FILENAME = 'C:\pruebasyh\yhprueba_fs'
)
LOG ON
(
    NAME = yhprueba_Log,
    FILENAME = 'C:\pruebasyh\yhprueba_Log.ldf',
    SIZE = 5MB,
    MAXSIZE = 50MB,
    FILEGROWTH = 1MB
)
GO

ALTER DATABASE yhprueba
SET FILESTREAM
(
    NON_TRANSACTED_ACCESS = FULL,
    DIRECTORY_NAME = 'yhprueba_fs'
)
GO

--CONSULTA

SELECT DB_NAME(database_id),
non_transacted_access,
non_transacted_access_desc
FROM sys.database_filestream_options;
GO


-- CREAR TABLA FILETABLE

USE yhprueba
GO
DROP TABLE IF EXISTS Yellow_filetable
GO
CREATE TABLE Yellow_filetable AS FileTable
WITH
(
	FileTable_Directory = 'Yellow_filetable',
	FileTable_Collate_FileName = DATABASE_DEFAULT,
	FileTable_streamid_unique_constraint_name=uq_stream_id
);
GO

-- LA CONSULTAMOS

SELECT * 
	FROM Yellow_filetable
GO

--stream_id	file_stream	name	path_locator	parent_path_locator	file_type	cached_file_size	creation_time	last_write_time	last_access_time	is_directory	is_offline	is_hidden	is_readonly	is_archive	is_system	is_temporary

