-- ROW LEVEL SECURITY WITH SQL SERVER

USE MASTER;
GO
DROP DATABASE IF EXISTS YH2
GO

CREATE DATABASE YH2
GO

USE YH2
GO
-- se crean usuarios, en este caso no controlamos su existencia previa pero es recomendable hacerlo con un DROP IF EXISTS
CREATE USER Jaime WITHOUT LOGIN;
CREATE USER Ricardo WITHOUT LOGIN;
CREATE USER Susana WITHOUT LOGIN;
GO

DROP TABLE IF EXISTS Cliente
GO

CREATE TABLE Cliente(
       Nombre varchar(100) NULL,
	   ClienteEmail varchar(100) NULL,
	   Agente varchar(20) NULL
);
GO

GRANT SELECT ON dbo.Cliente TO Jaime;
GRANT SELECT ON dbo.Cliente TO Ricardo;
GRANT SELECT ON dbo.Cliente TO Susana;
GO

INSERT INTO Cliente VALUES 
   ('ABC Company','Manager@ABC.COM','Jaime'),
   ('Info Services','info@AInfaSerice.COM','Jaime'),
   ('Washing-R-Us','HeadWasher@washrus.COM','Ricardo'),
   ('Blue Water Utilities','marketing@bluewater.COM','Ricardo'),
   ('Star Brite','steve@starbright.COM','Jaime'),
   ('Rainy Day Fund','Tom@rainydayfund','Susana');
GO
PRINT USER
GO
-- dbo
-- VER TODOS LOS REGISTROS
SELECT * FROM Cliente
GO

-- FUNCTION IN LINE TABLE
-- MIRAR PARA EL EXAMEN
CREATE OR ALTER FUNCTION fn_RowLevelSecurity (@FilterColumnName sysname)  -- par�metro
RETURNS TABLE
WITH SCHEMABINDING
as
    RETURN SELECT 1 as fn_SecureClienteData
	-- filter out records based on database user name
	WHERE @FilterColumnName = user_name();  -- User_name devuelve los datos del usuario activo  (funci�n)
GO
-- dbo aqu� ve los registros 
-- SECURITY POLICY FILTER PREDICATE. NOT ALLOW READ

CREATE SECURITY POLICY FilterCliente
ADD FILTER PREDICATE dbo.fn_RowLevelSecurity(Agente)
ON dbo.Cliente
WITH (STATE = ON);
GO
-- al activar la pol�tica de seguridad el dbo deja de ver los registros

-- LO COMPROBAMOS
SELECT * FROM Cliente
GO
-- Nombre	ClienteEmail	Agente
-- No aparecen registros 

-- Si probamos desde uno de los usuarios::
EXECUTE AS USER = 'Ricardo';
GO
SELECT * FROM Cliente
GO
-- Vemos que tiene acceso a los registros en donde aparece el usuario
-- Nombre         	ClienteEmail           	Agente
-- Washing-R-Us          	HeadWasher@washrus.COM  	Ricardo
-- Blue Water Utilities 	marketing@bluewater.COM  	Ricardo

PRINT USER
GO

--Ricardo
--Completion time: 2023-03-06T20:46:00.6610952+01:00

REVERT

EXECUTE AS USER = 'Jaime';
GO
SELECT * FROM Cliente
GO

-- Nombre 	ClienteEmail       	Agente
-- ABC Company  	Manager@ABC.COM     	Jaime
-- Info Services	info@AInfaSerice.COM	Jaime
-- Star Brite   	steve@starbright.COM	Jaime

REVERT

EXECUTE AS USER = 'Susana';
GO
SELECT * FROM Cliente
GO

-- Nombre  	ClienteEmail   	Agente
-- Rainy Day Fund	Tom@rainydayfund	Susana

REVERT
GO

GRANT UPDATE ON dbo.Cliente TO Jaime;
GRANT UPDATE ON dbo.Cliente TO Ricardo;
GRANT UPDATE ON dbo.Cliente TO Susana;
GO

EXECUTE AS USER = 'Jaime';
GO
SELECT * FROM Cliente
GO

-- UPDATE Cliente Record
-- PUEDE ACTUALIZAR FILAS CAMBIANDO Agente A OTRO USUARIO Ricardo
UPDATE Cliente
SET ClienteEmail = 'Jack@ABC.COM',
    Agente = 'Ricardo'
WHERE Nombre = 'ABC Company';
GO
--(1 row affected)
--Completion time: 2023-03-06T20:53:58.0902155+01:00

SELECT * FROM Cliente
GO
-- Vemos que el registro que le transfiri� a Ricardo ya no se puede ver

-- Nombre  	ClienteEmail        	Agente
-- Info Services	info@AInfaSerice.COM	Jaime
-- Star Brite   	steve@starbright.COM	Jaime

-- TAMBIEN PUEDE INSERTAR REGISTROS QUE NO SEAN SUYOS
PRINT USER
GO
-- Jaime

GRANT INSERT ON dbo.Cliente TO Jaime;
GRANT INSERT ON dbo.Cliente TO Ricardo;
GRANT INSERT ON dbo.Cliente TO Susana;
GO

-- INSERT new Cliente para Agente Susana
INSERT INTO Cliente VALUES
     ('Rock The Dock','Rocky@RockTheDock.COM','Susana');
GO
-- NO VE LO QUE INSERT� PERO PUEDE INSERTAR
SELECT * FROM Cliente
GO
--Nombre	ClienteEmail       	Agente
--Info Services	info@AInfaSerice.COM	Jaime
--Star Brite	steve@starbright.COM	Jaime

REVERT
GO

EXECUTE AS USER = 'Susana';
GO
SELECT * FROM Cliente
GO

-- Nombre  	ClienteEmail       	Agente
-- Rainy Day Fund	Tom@rainydayfund    	Susana
-- Rock The Dock	Rocky@RockTheDock.COM	Susana

REVERT 
GO

ALTER SECURITY POLICY FilterCliente
ADD BLOCK PREDICATE bod.fn_RowLevelSecurity(Agente)
ON dbo.Cliente AFTER UPDATE,
ADD BLOCK PREDICATE dbo.fn_RowLevelSecurity(Agente)
ON dbo.Cliente AFTER INSERT;
GO

-- The first "ADD BLOCK PREDICATE" clause with the "AFTER UPDATE" clause,
-- blocks updates to rows that don't pass the filter predicate
-- The second "ADD BLOCK PREDICATE" clause, with the "AFTER INSERT" clause;


GO

-- UPDATE Cliente record
EXECUTE AS USER = 'Jaime'
GO

-- ESTO ES LO QUE Jaime VE CON EL FILTER PREDICATE
SELECT Nombre, ClienteEmail, Agente
FROM Cliente;
GO




UPDATE Cliente
SET ClienteEmail = 'bloquear@ABC.COM',
    Agente = 'Ricardo'
WHERE Nombre = 'ABC Company';
GO

-- INSERT new Cliente
INSERT INTO Cliente VALUES
      ('Rock The Dock','Rocky@RockTheDock.com','Susana');
GO

REVERT
GO

GRANT DELETE ON dbo.Cliente TO Jaime;
GRANT DELETE ON dbo.Cliente TO Ricardo;
GRANT DELETE ON dbo.Cliente TO Susana;
GO

EXECUTE AS USER = 'Ricardo';
GO
DELETE FROM Cliente WHERE Nombre ='ABC Company'
GO

SELECT Nombre, ClienteEmail,Agente
FROM Cliente;
GO
-- VALOR


REVERT 
GO

-- A�ADO POL�TICA PARA PREVENIR BORRADO
ALTER SECURITY POLICY FilterCliente
ADD BLOCK PREDICATE dbo.fn_RowLevelSecurity(Agente)
ON dbo.Cliente BEFORE DELETE
GO
EXECUTE AS USER = 'Ricardo';
GO
DELETE FROM Cliente WHERE Nombre ='Star Brite'
GO

SELECT Nombre, ClienteEmail, Agente
FROM Cliente;
GO



