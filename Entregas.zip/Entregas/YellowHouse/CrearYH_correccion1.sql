
-- ##########################################
-- ## YELLOW HOUSE - AGENCIA DE MANAGEMENT ##
-- ##########################################

-- XOS� RAM�N PORTILLA PEDREDA

USE MASTER
GO

DROP DATABASE IF EXISTS YellowHouse
GO

CREATE DATABASE YellowHouse
GO

USE YellowHouse
GO


CREATE TABLE Aptitudes 
    (
     ID_apt INTEGER IDENTITY(1,1) NOT NULL , 
     Idiomas VARCHAR (255) NOT NULL , 
     Deporte VARCHAR (255) , 
     Baile VARCHAR (255) , 
     Actuacion VARCHAR (255) , 
     Canto VARCHAR (255) , 
     Musica VARCHAR (255) , 
     Escritura VARCHAR (255) 
    )
GO

ALTER TABLE Aptitudes ADD CONSTRAINT Aptitudes_PK PRIMARY KEY CLUSTERED (ID_apt)
     WITH (
     ALLOW_PAGE_LOCKS = ON , 
     ALLOW_ROW_LOCKS = ON )
GO

CREATE TABLE Asiste 
    (
     Empleado_ID_empleado INTEGER NOT NULL , 
     Evento_ID INTEGER NOT NULL 
    )
GO

ALTER TABLE Asiste ADD CONSTRAINT Relation_11_PK PRIMARY KEY CLUSTERED (Empleado_ID_empleado, Evento_ID)
     WITH (
     ALLOW_PAGE_LOCKS = ON , 
     ALLOW_ROW_LOCKS = ON )
GO

CREATE TABLE Cliente 
    (
     ID_cliente INTEGER IDENTITY(1,1) NOT NULL , 
     Sector VARCHAR (80) NOT NULL , 
     Web VARCHAR (150) NOT NULL , 
     Contrase�a VARCHAR (255) NOT NULL 
    )
GO

ALTER TABLE Cliente ADD CONSTRAINT Cliente_PK PRIMARY KEY CLUSTERED (ID_cliente)
     WITH (
     ALLOW_PAGE_LOCKS = ON , 
     ALLOW_ROW_LOCKS = ON )
GO

CREATE TABLE Cobro 
    (
     Cliente_ID_cliente INTEGER NOT NULL , 
     Asiento_Caja_ID INTEGER NOT NULL 
    )
GO

ALTER TABLE Cobro ADD CONSTRAINT Relation_16_PK PRIMARY KEY CLUSTERED (Cliente_ID_cliente, Asiento_Caja_ID)
     WITH (
     ALLOW_PAGE_LOCKS = ON , 
     ALLOW_ROW_LOCKS = ON )
GO

CREATE TABLE Colabora 
    (
     Colaborador_ID_colaborador INTEGER NOT NULL , 
     Evento_ID INTEGER NOT NULL 
    )
GO

ALTER TABLE Colabora ADD CONSTRAINT Relation_10_PK PRIMARY KEY CLUSTERED (Colaborador_ID_colaborador, Evento_ID)
     WITH (
     ALLOW_PAGE_LOCKS = ON , 
     ALLOW_ROW_LOCKS = ON )
GO

CREATE TABLE Colaborador 
    (
     ID_colaborador INTEGER IDENTITY(1,1) NOT NULL , 
     Sector VARCHAR (80) NOT NULL , 
     Web VARCHAR (150) NOT NULL , 
     Contrase�a VARCHAR (255) NOT NULL , 
     DatosPersonales_DNI_NIE_NIF VARCHAR (15) NOT NULL 
    )
GO

ALTER TABLE Colaborador ADD CONSTRAINT Colaborador_PK PRIMARY KEY CLUSTERED (ID_colaborador)
     WITH (
     ALLOW_PAGE_LOCKS = ON , 
     ALLOW_ROW_LOCKS = ON )
GO

CREATE TABLE Datos_Aspecto 
    (
     ID_aspecto INTEGER IDENTITY(1,1) NOT NULL , 
     Genero VARCHAR (15) NOT NULL , 
     Color_Ojos VARCHAR (12) NOT NULL , 
     Color_pelo VARCHAR (12) NOT NULL , 
     Longitud_Pelo VARCHAR (15) NOT NULL , 
     Tatuajes VARCHAR (50) NOT NULL , 
     Medidas_ID_med INTEGER NOT NULL 
    )
GO

ALTER TABLE Datos_Aspecto ADD CONSTRAINT Datos_Aspecto_PK PRIMARY KEY CLUSTERED (ID_aspecto)
     WITH (
     ALLOW_PAGE_LOCKS = ON , 
     ALLOW_ROW_LOCKS = ON )
GO

CREATE TABLE DatosPersonales 
    (
     DNI_NIE_NIF VARCHAR (15) NOT NULL , 
     Nombre VARCHAR (40) NOT NULL , 
     Apellidos VARCHAR (90) , 
     Domicilio VARCHAR (120) NOT NULL , 
     Telefono VARCHAR (15) NOT NULL , 
     email VARCHAR (150) NOT NULL , 
     Localizaci�n_ID_local INTEGER NOT NULL , 
     Empleado_ID_empleado INTEGER NOT NULL , 
     Cliente_ID_cliente INTEGER NOT NULL 
    )
GO 

    


CREATE UNIQUE NONCLUSTERED INDEX 
    DatosPersonales__IDX ON DatosPersonales 
    ( 
     Cliente_ID_cliente 
    ) 
GO 


CREATE UNIQUE NONCLUSTERED INDEX 
    DatosPersonales__IDXv1 ON DatosPersonales 
    ( 
     Empleado_ID_empleado 
    ) 
GO

ALTER TABLE DatosPersonales ADD CONSTRAINT DatosPersonales_PK PRIMARY KEY CLUSTERED (DNI_NIE_NIF)
     WITH (
     ALLOW_PAGE_LOCKS = ON , 
     ALLOW_ROW_LOCKS = ON )
GO

CREATE TABLE Empleado 
    (
     ID_empleado INTEGER IDENTITY(1,1) NOT NULL , 
     Puesto VARCHAR (30) NOT NULL , 
     Nivel_acceso VARCHAR (30) NOT NULL , 
     Contrase�a VARCHAR (255) NOT NULL 
    )
GO

ALTER TABLE Empleado ADD CONSTRAINT Empleado_PK PRIMARY KEY CLUSTERED (ID_empleado)
     WITH (
     ALLOW_PAGE_LOCKS = ON , 
     ALLOW_ROW_LOCKS = ON )
GO

CREATE TABLE Entrevista 
    (
     ID_entrevista INTEGER IDENTITY(1,1) NOT NULL , 
     Formato VARCHAR (40) NOT NULL , 
     Medio VARCHAR (60) NOT NULL 
    )
GO

ALTER TABLE Entrevista ADD CONSTRAINT Entrevista_PK PRIMARY KEY CLUSTERED (ID_entrevista)
     WITH (
     ALLOW_PAGE_LOCKS = ON , 
     ALLOW_ROW_LOCKS = ON )
GO

CREATE TABLE Evento 
    (
     ID INTEGER IDENTITY(1,1) NOT NULL , 
     Tipo_evento VARCHAR (60) NOT NULL , 
     Fecha DATE NOT NULL , 
     Hora TIME NOT NULL , 
     Duracion VARCHAR (30) NOT NULL , 
     lugar VARCHAR (200) NOT NULL 
    )
GO

ALTER TABLE Evento ADD CONSTRAINT Evento_PK PRIMARY KEY CLUSTERED (ID)
     WITH (
     ALLOW_PAGE_LOCKS = ON , 
     ALLOW_ROW_LOCKS = ON )
GO

CREATE TABLE Factura 
    (
     Colaborador_ID_colaborador INTEGER NOT NULL , 
     Asiento_Caja_ID INTEGER NOT NULL 
    )
GO

ALTER TABLE Factura ADD CONSTRAINT Relation_14_PK PRIMARY KEY CLUSTERED (Colaborador_ID_colaborador, Asiento_Caja_ID)
     WITH (
     ALLOW_PAGE_LOCKS = ON , 
     ALLOW_ROW_LOCKS = ON )
GO

CREATE TABLE Localizaci�n 
    (
     ID_local INTEGER IDENTITY(1,1) NOT NULL , 
     Pais VARCHAR (50) NOT NULL , 
     Provincia_Estado VARCHAR (50) NOT NULL , 
     Localidad VARCHAR (90) NOT NULL , 
     Codigo_Postal VARCHAR (7) NOT NULL 
    )
GO

ALTER TABLE Localizaci�n ADD CONSTRAINT Localizaci�n_PK PRIMARY KEY CLUSTERED (ID_local)
     WITH (
     ALLOW_PAGE_LOCKS = ON , 
     ALLOW_ROW_LOCKS = ON )
GO

CREATE TABLE Media 
    (
     ID_Media INTEGER IDENTITY(1,1) NOT NULL , 
     Fotos VARCHAR (200) NOT NULL , 
     Videos VARCHAR (200) , 
     Redes_sociales VARCHAR (255) NOT NULL , 
     Entrevista_ID_entrevista INTEGER NOT NULL 
    )
GO

ALTER TABLE Media ADD CONSTRAINT Media_PK PRIMARY KEY CLUSTERED (ID_Media)
     WITH (
     ALLOW_PAGE_LOCKS = ON , 
     ALLOW_ROW_LOCKS = ON )
GO

CREATE TABLE Medidas 
    (
     ID_med INTEGER IDENTITY(1,1) NOT NULL , 
     Altura_cm CHAR(3) NOT NULL , 
     Peso VARCHAR(3) NOT NULL , 
     Talla_calzado CHAR(2) NOT NULL , 
     Talla_busto VARCHAR(3) NOT NULL , 
     Talla_cintura VARCHAR(3) NOT NULL , 
     Talla_caderas VARCHAR(3) NOT NULL , 
     Talla_ropa VARCHAR(10) NOT NULL 
    )
GO

ALTER TABLE Medidas ADD CONSTRAINT Medidas_PK PRIMARY KEY CLUSTERED (ID_med)
     WITH (
     ALLOW_PAGE_LOCKS = ON , 
     ALLOW_ROW_LOCKS = ON )
GO

CREATE TABLE Organiza 
    (
     Cliente_ID_cliente INTEGER NOT NULL , 
     Evento_ID INTEGER NOT NULL 
    )
GO

ALTER TABLE Organiza ADD CONSTRAINT Relation_12_PK PRIMARY KEY CLUSTERED (Cliente_ID_cliente, Evento_ID)
     WITH (
     ALLOW_PAGE_LOCKS = ON , 
     ALLOW_ROW_LOCKS = ON )
GO

CREATE TABLE Pago 
    (
     Representado_ID INTEGER NOT NULL , 
     Asiento_Caja_ID INTEGER NOT NULL 
    )
GO

ALTER TABLE Pago ADD CONSTRAINT Relation_13_PK PRIMARY KEY CLUSTERED (Representado_ID, Asiento_Caja_ID)
     WITH (
     ALLOW_PAGE_LOCKS = ON , 
     ALLOW_ROW_LOCKS = ON )
GO

CREATE TABLE Pago_Nomina 
    (
     Empleado_ID_empleado INTEGER NOT NULL , 
     Asiento_Caja_ID INTEGER NOT NULL 
    )
GO

ALTER TABLE Pago_Nomina ADD CONSTRAINT Relation_15_PK PRIMARY KEY CLUSTERED (Empleado_ID_empleado, Asiento_Caja_ID)
     WITH (
     ALLOW_PAGE_LOCKS = ON , 
     ALLOW_ROW_LOCKS = ON )
GO

CREATE TABLE Participa 
    (
     Evento_ID INTEGER NOT NULL , 
     Representado_ID INTEGER NOT NULL 
    )
GO

ALTER TABLE Participa ADD CONSTRAINT Relation_6_PK PRIMARY KEY CLUSTERED (Evento_ID, Representado_ID)
     WITH (
     ALLOW_PAGE_LOCKS = ON , 
     ALLOW_ROW_LOCKS = ON )
GO

CREATE TABLE Representado 
    (
     ID INTEGER IDENTITY(1,1) NOT NULL , 
     DatosPersonales_DNI_NIE_NIF VARCHAR (15) NOT NULL , 
     ID_med INTEGER NOT NULL , 
     Aptitudes_ID_apt INTEGER NOT NULL , 
     Media_ID_Media INTEGER NOT NULL , 
     Fecha_alta DATE NOT NULL , 
     Datos_Aspecto_ID_aspecto INTEGER NOT NULL 
    )
GO

ALTER TABLE Representado ADD CONSTRAINT Representado_PK PRIMARY KEY CLUSTERED (ID)
     WITH (
     ALLOW_PAGE_LOCKS = ON , 
     ALLOW_ROW_LOCKS = ON )
GO

CREATE TABLE Transacci�n 
    (
     ID INTEGER IDENTITY(1,1) NOT NULL , 
     Fecha DATE NOT NULL , 
     Tipo VARCHAR (15) NOT NULL , 
     Importe MONEY NOT NULL 
    )
GO

ALTER TABLE Transacci�n ADD CONSTRAINT Transacci�n_PK PRIMARY KEY CLUSTERED (ID)
     WITH (
     ALLOW_PAGE_LOCKS = ON , 
     ALLOW_ROW_LOCKS = ON )
GO

ALTER TABLE Colaborador 
    ADD CONSTRAINT Colaborador_DatosPersonales_FK FOREIGN KEY 
    ( 
     DatosPersonales_DNI_NIE_NIF
    ) 
    REFERENCES DatosPersonales 
    ( 
     DNI_NIE_NIF 
    ) 
    ON DELETE NO ACTION 
    ON UPDATE NO ACTION 
GO

ALTER TABLE Datos_Aspecto 
    ADD CONSTRAINT Datos_Aspecto_Medidas_FK FOREIGN KEY 
    ( 
     Medidas_ID_med
    ) 
    REFERENCES Medidas 
    ( 
     ID_med 
    ) 
    ON DELETE NO ACTION 
    ON UPDATE NO ACTION 
GO

ALTER TABLE DatosPersonales 
    ADD CONSTRAINT DatosPersonales_Cliente_FK FOREIGN KEY 
    ( 
     Cliente_ID_cliente
    ) 
    REFERENCES Cliente 
    ( 
     ID_cliente 
    ) 
    ON DELETE NO ACTION 
    ON UPDATE NO ACTION 
GO

ALTER TABLE DatosPersonales 
    ADD CONSTRAINT DatosPersonales_Empleado_FK FOREIGN KEY 
    ( 
     Empleado_ID_empleado
    ) 
    REFERENCES Empleado 
    ( 
     ID_empleado 
    ) 
    ON DELETE NO ACTION 
    ON UPDATE NO ACTION 
GO

ALTER TABLE DatosPersonales 
    ADD CONSTRAINT DatosPersonales_Localizaci�n_FK FOREIGN KEY 
    ( 
     Localizaci�n_ID_local
    ) 
    REFERENCES Localizaci�n 
    ( 
     ID_local 
    ) 
    ON DELETE NO ACTION 
    ON UPDATE NO ACTION 
GO

ALTER TABLE Media 
    ADD CONSTRAINT Media_Entrevista_FK FOREIGN KEY 
    ( 
     Entrevista_ID_entrevista
    ) 
    REFERENCES Entrevista 
    ( 
     ID_entrevista 
    ) 
    ON DELETE NO ACTION 
    ON UPDATE NO ACTION 
GO

ALTER TABLE Colabora 
    ADD CONSTRAINT Relation_10_Colaborador_FK FOREIGN KEY 
    ( 
     Colaborador_ID_colaborador
    ) 
    REFERENCES Colaborador 
    ( 
     ID_colaborador 
    ) 
    ON DELETE NO ACTION 
    ON UPDATE NO ACTION 
GO

ALTER TABLE Colabora 
    ADD CONSTRAINT Relation_10_Evento_FK FOREIGN KEY 
    ( 
     Evento_ID
    ) 
    REFERENCES Evento 
    ( 
     ID 
    ) 
    ON DELETE NO ACTION 
    ON UPDATE NO ACTION 
GO

ALTER TABLE Asiste 
    ADD CONSTRAINT Relation_11_Empleado_FK FOREIGN KEY 
    ( 
     Empleado_ID_empleado
    ) 
    REFERENCES Empleado 
    ( 
     ID_empleado 
    ) 
    ON DELETE NO ACTION 
    ON UPDATE NO ACTION 
GO

ALTER TABLE Asiste 
    ADD CONSTRAINT Relation_11_Evento_FK FOREIGN KEY 
    ( 
     Evento_ID
    ) 
    REFERENCES Evento 
    ( 
     ID 
    ) 
    ON DELETE NO ACTION 
    ON UPDATE NO ACTION 
GO

ALTER TABLE Organiza 
    ADD CONSTRAINT Relation_12_Cliente_FK FOREIGN KEY 
    ( 
     Cliente_ID_cliente
    ) 
    REFERENCES Cliente 
    ( 
     ID_cliente 
    ) 
    ON DELETE NO ACTION 
    ON UPDATE NO ACTION 
GO

ALTER TABLE Organiza 
    ADD CONSTRAINT Relation_12_Evento_FK FOREIGN KEY 
    ( 
     Evento_ID
    ) 
    REFERENCES Evento 
    ( 
     ID 
    ) 
    ON DELETE NO ACTION 
    ON UPDATE NO ACTION 
GO

ALTER TABLE Pago 
    ADD CONSTRAINT Relation_13_Asiento_Caja_FK FOREIGN KEY 
    ( 
     Asiento_Caja_ID
    ) 
    REFERENCES Transacci�n 
    ( 
     ID 
    ) 
    ON DELETE NO ACTION 
    ON UPDATE NO ACTION 
GO

ALTER TABLE Pago 
    ADD CONSTRAINT Relation_13_Representado_FK FOREIGN KEY 
    ( 
     Representado_ID
    ) 
    REFERENCES Representado 
    ( 
     ID 
    ) 
    ON DELETE NO ACTION 
    ON UPDATE NO ACTION 
GO

ALTER TABLE Factura 
    ADD CONSTRAINT Relation_14_Asiento_Caja_FK FOREIGN KEY 
    ( 
     Asiento_Caja_ID
    ) 
    REFERENCES Transacci�n 
    ( 
     ID 
    ) 
    ON DELETE NO ACTION 
    ON UPDATE NO ACTION 
GO

ALTER TABLE Factura 
    ADD CONSTRAINT Relation_14_Colaborador_FK FOREIGN KEY 
    ( 
     Colaborador_ID_colaborador
    ) 
    REFERENCES Colaborador 
    ( 
     ID_colaborador 
    ) 
    ON DELETE NO ACTION 
    ON UPDATE NO ACTION 
GO

ALTER TABLE Pago_Nomina 
    ADD CONSTRAINT Relation_15_Asiento_Caja_FK FOREIGN KEY 
    ( 
     Asiento_Caja_ID
    ) 
    REFERENCES Transacci�n 
    ( 
     ID 
    ) 
    ON DELETE NO ACTION 
    ON UPDATE NO ACTION 
GO

ALTER TABLE Pago_Nomina 
    ADD CONSTRAINT Relation_15_Empleado_FK FOREIGN KEY 
    ( 
     Empleado_ID_empleado
    ) 
    REFERENCES Empleado 
    ( 
     ID_empleado 
    ) 
    ON DELETE NO ACTION 
    ON UPDATE NO ACTION 
GO

ALTER TABLE Cobro 
    ADD CONSTRAINT Relation_16_Asiento_Caja_FK FOREIGN KEY 
    ( 
     Asiento_Caja_ID
    ) 
    REFERENCES Transacci�n 
    ( 
     ID 
    ) 
    ON DELETE NO ACTION 
    ON UPDATE NO ACTION 
GO

ALTER TABLE Cobro 
    ADD CONSTRAINT Relation_16_Cliente_FK FOREIGN KEY 
    ( 
     Cliente_ID_cliente
    ) 
    REFERENCES Cliente 
    ( 
     ID_cliente 
    ) 
    ON DELETE NO ACTION 
    ON UPDATE NO ACTION 
GO

ALTER TABLE Participa 
    ADD CONSTRAINT Relation_6_Evento_FK FOREIGN KEY 
    ( 
     Evento_ID
    ) 
    REFERENCES Evento 
    ( 
     ID 
    ) 
    ON DELETE NO ACTION 
    ON UPDATE NO ACTION 
GO

ALTER TABLE Participa 
    ADD CONSTRAINT Relation_6_Representado_FK FOREIGN KEY 
    ( 
     Representado_ID
    ) 
    REFERENCES Representado 
    ( 
     ID 
    ) 
    ON DELETE NO ACTION 
    ON UPDATE NO ACTION 
GO

ALTER TABLE Representado 
    ADD CONSTRAINT Representado_Aptitudes_FK FOREIGN KEY 
    ( 
     Aptitudes_ID_apt
    ) 
    REFERENCES Aptitudes 
    ( 
     ID_apt 
    ) 
    ON DELETE NO ACTION 
    ON UPDATE NO ACTION 
GO

ALTER TABLE Representado 
    ADD CONSTRAINT Representado_Datos_Aspecto_FK FOREIGN KEY 
    ( 
     Datos_Aspecto_ID_aspecto
    ) 
    REFERENCES Datos_Aspecto 
    ( 
     ID_aspecto 
    ) 
    ON DELETE NO ACTION 
    ON UPDATE NO ACTION 
GO

ALTER TABLE Representado 
    ADD CONSTRAINT Representado_DatosPersonales_FK FOREIGN KEY 
    ( 
     DatosPersonales_DNI_NIE_NIF
    ) 
    REFERENCES DatosPersonales 
    ( 
     DNI_NIE_NIF 
    ) 
    ON DELETE NO ACTION 
    ON UPDATE NO ACTION 
GO

ALTER TABLE Representado 
    ADD CONSTRAINT Representado_Media_FK FOREIGN KEY 
    ( 
     Media_ID_Media
    ) 
    REFERENCES Media 
    ( 
     ID_Media 
    ) 
    ON DELETE NO ACTION 
    ON UPDATE NO ACTION 
GO



-- Informe de Resumen de Oracle SQL Developer Data Modeler: 
-- 
-- CREATE TABLE                            21
-- CREATE INDEX                             2
-- ALTER TABLE                             47
-- CREATE VIEW                              0
-- ALTER VIEW                               0
-- CREATE PACKAGE                           0
-- CREATE PACKAGE BODY                      0
-- CREATE PROCEDURE                         0
-- CREATE FUNCTION                          0
-- CREATE TRIGGER                           0
-- ALTER TRIGGER                            0
-- CREATE DATABASE                          0
-- CREATE DEFAULT                           0
-- CREATE INDEX ON VIEW                     0
-- CREATE ROLLBACK SEGMENT                  0
-- CREATE ROLE                              0
-- CREATE RULE                              0
-- CREATE SCHEMA                            0
-- CREATE SEQUENCE                          0
-- CREATE PARTITION FUNCTION                0
-- CREATE PARTITION SCHEME                  0
-- 
-- DROP DATABASE                            0
-- 
-- ERRORS                                   0
-- WARNINGS                                 0
