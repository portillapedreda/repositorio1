--Buscamos el "compatibility_level" de la tabla "sys.databases" 
 --filtrando por el nombre de la base de datos actual utilizando la funci�n "Db_Name()".


SELECT d.compatibility_level
    FROM sys.databases as d
    WHERE d.name = Db_Name();
GO

--compatibility_level
--         150


-- Creamos la base de datos controlando su existencia 
-- y activamos la base de datos con USE

USE master 
GO
DROP DATABASE IF EXISTS YH_InMemory
GO
CREATE DATABASE YH_InMemory
GO
USE YH_InMemory
GO

-- La opci�n "MEMORY_OPTIMIZED_ELEVATE_TO_SNAPSHOT" establece un nivel de aislamiento 
-- de transacciones espec�fico para las transacciones que involucran tablas in memory

ALTER DATABASE YH_InMemory
SET MEMORY_OPTIMIZED_ELEVATE_TO_SNAPSHOT = ON;
GO

--Activamos la opci�n que establece el nivel de compatibilidad de una base 
--de datos llamada "YH_InMemory" a la versi�n 150 de SQL Server.


ALTER DATABASE YH_InMemory
SET COMPATIBILITY_LEVEL = 150;
GO

-- A�adimos un nuevo filegroup a la base de datos con el fin de almacenar datos
--optimizados en memoria

ALTER DATABASE YH_InMemory
	ADD FILEGROUP YH_InMemory_mod 
	CONTAINS MEMORY_OPTIMIZED_DATA;
go

-- Agregamos un nuevo archivo de datos a un grupo de archivos de memoria optimizados y lo llamamos YH_InMemory_mod.


ALTER DATABASE YH_InMemory
ADD FILE 
	(name='YH_InMemory_mod1', 
	filename='c:\datos\YH_InMemory_mod1')
	TO FILEGROUP YH_InMemory_mod
go


-- Ahora vamos a crear la tabla optimizada

DROP TABLE IF EXISTS dbo.pagos
GO
CREATE TABLE dbo.pagos
    (
        OrderID   INTEGER   NOT NULL   IDENTITY
            PRIMARY KEY NONCLUSTERED,
        ItemNumber   INTEGER    NOT NULL,
        OrderDate    DATETIME   NOT NULL
    )
        WITH
            (MEMORY_OPTIMIZED = ON,-----------Opci�n tabla en memoria
            DURABILITY = SCHEMA_AND_DATA);---- significa que los datos y el esquema de la tabla se almacenan en memoria 
											--y se guardan en el disco para la persistencia.
GO