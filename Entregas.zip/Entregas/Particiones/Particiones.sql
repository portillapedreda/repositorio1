-- CREAMOS LA BASE DE DATOS CON SUS ARCHIVOS PRINCIPALES .mdf y .ldf

USE master 
go

DROP DATABASE IF EXISTS yh1 
GO
CREATE DATABASE yh1 
	ON PRIMARY ( NAME = 'yh1', 
		FILENAME = 'C:\datos\yh1_Fijo.mdf' , 
		SIZE = 15360KB , MAXSIZE = UNLIMITED, FILEGROWTH = 0) 
	LOG ON ( NAME = 'yh1_log', 
		FILENAME = 'C:\datos\yh1_log.ldf' , 
		SIZE = 10176KB , MAXSIZE = 2048GB , FILEGROWTH = 10%) 
GO

--ACTIVAMOS  LA BASE

USE yh1
GO

-- CREAMOS LOS FILEGROUPS
-- CREAMOS 4 FILEGROUPS PARA CONTENER LAS PARTICIONES DESEADAS

ALTER DATABASE [yh1] ADD FILEGROUP [FG_Archivo] 
GO 
ALTER DATABASE [yh1] ADD FILEGROUP [FG_1] 
GO 
ALTER DATABASE [yh1] ADD FILEGROUP [FG_2] 
GO 
ALTER DATABASE [yh1] ADD FILEGROUP [FG_3]
GO



select * from sys.filegroups
GO

--name	data_space_id	type	type_desc	is_default	is_system	filegroup_guid	log_filegroup_id	is_read_only	is_autogrow_all_files
--PRIMARY	1	FG	ROWS_FILEGROUP	1	0	NULL	NULL	0	0
--FG_Archivo	2	FG	ROWS_FILEGROUP	0	0	62551024-192B-4058-97C3-083BCDF5B486	NULL	0	0
--FG_1	3	FG	ROWS_FILEGROUP	0	0	D0030BEA-C7A5-46B4-9CB8-469C00884596	NULL	0	0
--FG_2	4	FG	ROWS_FILEGROUP	0	0	CCD79441-FC67-4857-8543-9F55E3D40A2C	NULL	0	0
--FG_3	5	FG	ROWS_FILEGROUP	0	0	7D013245-7472-4FA4-96F0-1AE62B9D0F26	NULL	0	0

-- CREAMOS LOS FICHEROS

ALTER DATABASE [yh1] ADD FILE ( NAME = 'yellow_Archivo', FILENAME = 'c:\datos\yellow_Archivo.ndf', SIZE = 5MB, MAXSIZE = 100MB, FILEGROWTH = 2MB ) TO FILEGROUP [FG_Archivo] 
GO
ALTER DATABASE [yh1] ADD FILE ( NAME = 'yellow1', FILENAME = 'c:\datos\yellow1.ndf', SIZE = 5MB, MAXSIZE = 100MB, FILEGROWTH = 2MB ) TO FILEGROUP [FG_1] 
GO
ALTER DATABASE [yh1] ADD FILE ( NAME = 'yellow2', FILENAME = 'c:\datos\yellow2.ndf', SIZE = 5MB, MAXSIZE = 100MB, FILEGROWTH = 2MB ) TO FILEGROUP [FG_2] 
GO
ALTER DATABASE [yh1] ADD FILE ( NAME = 'yellow3', FILENAME = 'c:\datos\yellow3.ndf', SIZE = 5MB, MAXSIZE = 100MB, FILEGROWTH = 2MB ) TO FILEGROUP [FG_3] 
GO


select * from sys.filegroups
GO

select * from sys.database_files
GO

--file_id	file_guid	type	type_desc	data_space_id	name	physical_name	state	state_desc	size	max_size	growth	is_media_read_only	is_read_only	is_sparse	is_percent_growth	is_name_reserved	is_persistent_log_buffer	create_lsn	drop_lsn	read_only_lsn	read_write_lsn	differential_base_lsn	differential_base_guid	differential_base_time	redo_start_lsn	redo_start_fork_guid	redo_target_lsn	redo_target_fork_guid	backup_lsn
--1	9AF59347-A062-4A24-B425-1F94636B3FC6	0	ROWS	1	yh1	C:\datos\yh1_Fijo.mdf	0	ONLINE	1920	-1	0	0	0	0	0	0	0	NULL	NULL	NULL	NULL	NULL	NULL	NULL	NULL	NULL	NULL	NULL	NULL
--2	E3DF7144-B9A6-4574-8B79-BE01FCE7BACA	1	LOG	0	yh1_log	C:\datos\yh1_log.ldf	0	ONLINE	1272	268435456	10	0	0	0	1	0	0	NULL	NULL	NULL	NULL	NULL	NULL	NULL	NULL	NULL	NULL	NULL	NULL
--3	1D507DE1-6819-4E9F-87DE-F9F93D308170	0	ROWS	2	yellow_Archivo	c:\datos\yellow_Archivo.ndf	0	ONLINE	640	12800	256	0	0	0	0	0	0	37000000023100001	NULL	NULL	NULL	NULL	NULL	NULL	NULL	NULL	NULL	NULL	NULL
--4	9EFA8445-1212-48D9-BE98-852C57D85898	0	ROWS	3	yellow1	c:\datos\yellow1.ndf	0	ONLINE	640	12800	256	0	0	0	0	0	0	37000000025900001	NULL	NULL	NULL	NULL	NULL	NULL	NULL	NULL	NULL	NULL	NULL
--5	8019362D-57AE-464C-A518-4A2CA647A462	0	ROWS	4	yellow2	c:\datos\yellow2.ndf	0	ONLINE	640	12800	256	0	0	0	0	0	0	37000000028700001	NULL	NULL	NULL	NULL	NULL	NULL	NULL	NULL	NULL	NULL	NULL
--6	D18E2E6D-94D7-4866-AE31-07768DA2DF58	0	ROWS	5	yellow3	c:\datos\yellow3.ndf	0	ONLINE	640	12800	256	0	0	0	0	0	0	37000000031500001	NULL	NULL	NULL	NULL	NULL	NULL	NULL	NULL	NULL	NULL	NULL

-- CREAMOS LA FUNCION  DE PARTICI�N CON SUS LIMITES 
-- AS RANGE RIGHT: marcamos los valores que no est�n dentro de los rangos asignados.



CREATE PARTITION FUNCTION FN_altayh (datetime) 
AS RANGE RIGHT 
	FOR VALUES ('2017-01-01','2019-31-12')
GO

-- CREAMOS EL ESQUEMA DE LA PARTICION 

CREATE PARTITION SCHEME altayh_fecha 
AS PARTITION FN_altayh
	TO (FG_Archivo,FG_1,FG_2,FG_3) 
GO

---CREAMOS LA TABLA 

DROP TABLE IF EXISTS altayh
GO
CREATE TABLE altayh
	( id_alta int identity (1,1), 
	nombre varchar(20), 
	apellido varchar (20), 
	fecha_alta datetime ) 
	ON altayh_fecha 
		(fecha_alta) 
GO

-- INSERTAMOS DATOS

INSERT INTO altayh 
	Values ('Daniela','Gonz�lez','2017-13-10'),
           ('Juan','Mart�nez','2018-05-02'),
           ('Sof�a','Ramos','2018-27-12'), 
			('Lenny','Greta','2017-08-11')
Go

-- METADATA INFORMATION

SELECT *,$Partition.FN_altayh(fecha_alta) AS Partition
FROM altayh
GO


--id_alta	nombre	apellido	fecha_alta	Partition
--1	Daniela	Gonz�lez	2017-10-13 00:00:00.000	1
--4	Lenny	Greta	2017-11-08 00:00:00.000	1
--2	Juan	Mart�nez	2018-02-05 00:00:00.000	2
--3	Sof�a	Ramos	2018-12-27 00:00:00.000	2



--METEMOS OTROS TRES REGISTROS

INSERT INTO altayh 
	VALUES ('Federico','D�az','2017-21-06'),
           ('Luc�a','Romero','2019-19-11'),
           ('Tom�s','Castillo','2018-09-04')
GO

--VERIFICAMOS


SELECT *,$Partition.FN_altayh(fecha_alta) 
FROM altayh
GO

--id_alta	nombre	apellido	fecha_alta	(Sin nombre de columna)
--1	Daniela	Gonz�lez	2017-10-13 00:00:00.000	1
--4	Lenny	Greta	2017-11-08 00:00:00.000	1
--5	Federico	D�az	2017-06-21 00:00:00.000	1
--2	Juan	Mart�nez	2018-02-05 00:00:00.000	2
--3	Sof�a	Ramos	2018-12-27 00:00:00.000	2
--7	Tom�s	Castillo	2018-04-09 00:00:00.000	2
--6	Luc�a	Romero	2019-11-19 00:00:00.000	3


--PARA VER CUANTOS REGISTROS TIENE CADA PARTICI�N

select p.partition_number, p.rows from sys.partitions p 
inner join sys.tables t 
on p.object_id=t.object_id and t.name = 'altayh' 
GO

--partition_number	rows
--1              	3
--2             	3
--3             	1

--METEMOS OTROS 4 REGISTROS

INSERT INTO altayh
	VALUES ('Gabriela','L�pez','2019-29-07'),
           ('Mateo','S�nchez','2017-12-03'),
           ('Valentina','Garc�a','2018-06-06'),
           ('Nicol�s','Fern�ndez','2019-15-04')
GO



--VEMOS LO QUE HEMOS INTRODUCIDO

SELECT *,$Partition.FN_altayh(fecha_alta) 
FROM altayh
GO

--id_alta	nombre	apellido	fecha_alta	(Sin nombre de columna)
--1	Daniela	Gonz�lez	2017-10-13 00:00:00.000	1
--4	Lenny	Greta	2017-11-08 00:00:00.000	1
--5	Federico	D�az	2017-06-21 00:00:00.000	1
--9	Mateo	S�nchez	2017-03-12 00:00:00.000	1
--2	Juan	Mart�nez	2018-02-05 00:00:00.000	2
--3	Sof�a	Ramos	2018-12-27 00:00:00.000	2
--7	Tom�s	Castillo	2018-04-09 00:00:00.000	2
--10	Valentina	Garc�a	2018-06-06 00:00:00.000	2
--6	Luc�a	Romero	2019-11-19 00:00:00.000	3
--8	Gabriela	L�pez	2019-07-29 00:00:00.000	3
--11	Nicol�s	Fern�ndez	2019-04-15 00:00:00.000	3



--OTROS 5 REGISTROS PERO DEL 2018

INSERT INTO altayh 
	VALUES ('Isabella','Hern�ndez','2018-30-12'),
           ('Emilio','V�zquez','2018-08-08'),
		   ('Renata','Jim�nez','2018-22-02'),
           ('Joaqu�n','P�rez','2018-05-09'),
           ('Camila','�lvarez','2018-24-01')
GO

-- VEMOS AHORA QUE A MAYOR�A DE REGISTROS EST�N EN LA MISMA PARTICI�N
-- PARA ESO UTILIZAREMOS EL PROCESO DE SPLIT RANGE PARA DIVIDIR LOS DATOS
-- Y ASI REDISTRIBUIR BIEN LOS MISMOS


SELECT *,$Partition.FN_altayh(fecha_alta) as PARTITION
FROM altayh
GO

--id_alta	nombre  	apellido	fecha_alta          	PARTITION
--1     	Daniela  	Gonz�lez	2017-10-13 00:00:00.000 	1
--4     	Lenny   	Greta   	2017-11-08 00:00:00.000 	1
--5     	Federico	D�az    	2017-06-21 00:00:00.000 	1
--9     	Mateo   	S�nchez	    2017-03-12 00:00:00.000 	1
--2      	Juan    	Mart�nez	2018-02-05 00:00:00.000 	2
--3     	Sof�a   	Ramos    	2018-12-27 00:00:00.000 	2
--7	        Tom�s   	Castillo	2018-04-09 00:00:00.000 	2
--10     	Valentina	Garc�a   	2018-06-06 00:00:00.000 	2
--12    	Isabella	Hern�ndez	2018-12-30 00:00:00.000 	2
--13    	Emilio   	V�zquez  	2018-08-08 00:00:00.000 	2
--14    	Renata   	Jim�nez  	2018-02-22 00:00:00.000 	2
--15    	Joaqu�n  	P�rez   	2018-09-05 00:00:00.000 	2
--16    	Camila   	�lvarez  	2018-01-24 00:00:00.000 	2
--6     	Luc�a   	Romero  	2019-11-19 00:00:00.000 	3
--8     	Gabriela	L�pez    	2019-07-29 00:00:00.000 	3
--11     	Nicol�s   	Fern�ndez	2019-04-15 00:00:00.000 	3






--------------------- SPLIT -------------------
---EL SPLIT RANGE ES UN PROCESO QUE SE UTILIZA EN LA GESTI�N DE PARTICIONES
-- DE TABLAS EN UNA BASE DE DATOS PARA REDISTRIBUIR LOS DATOS ENTRE LAS PARTICIONES.
--PARA SEPARAR EL 2018 EN DOS PARTES (DEL 1 de Enero al 30 de Junio la primera parte 
--y del 1 de Julio al 31 de Diciemrbe la segunda) Y CREAR OTRA PARTCICI�N


ALTER PARTITION FUNCTION FN_altayh() 
	SPLIT RANGE ('2018-01-01'); 
GO

SELECT *,$Partition.FN_altayh(fecha_alta) as PARTITION
FROM altayh
GO

--id_alta	nombre	apellido	fecha_alta	PARTITION
--1	Daniela	Gonz�lez	2017-10-13 00:00:00.000	2
--4	Lenny	Greta	2017-11-08 00:00:00.000	2
--5	Federico	D�az	2017-06-21 00:00:00.000	2
--9	Mateo	S�nchez	2017-03-12 00:00:00.000	2
--2	Juan	Mart�nez	2018-02-05 00:00:00.000	3
--3	Sof�a	Ramos	2018-12-27 00:00:00.000	3
--6	Luc�a	Romero	2019-11-19 00:00:00.000	3
--7	Tom�s	Castillo	2018-04-09 00:00:00.000	3
--8	Gabriela	L�pez	2019-07-29 00:00:00.000	3
--10	Valentina	Garc�a	2018-06-06 00:00:00.000	3
--11	Nicol�s	Fern�ndez	2019-04-15 00:00:00.000	3
--12	Isabella	Hern�ndez	2018-12-30 00:00:00.000	3
--13	Emilio	V�zquez	2018-08-08 00:00:00.000	3
--14	Renata	Jim�nez	2018-02-22 00:00:00.000	3
--15	Joaqu�n	P�rez	2018-09-05 00:00:00.000	3
-16	Camila	�lvarez	2018-01-24 00:00:00.000	3





-------------- MERGE---------------------------

---- EL COMANDO MERGE SE PUEDE UTILIZAR PARA COMBINAR LOS DATOS DE UNA TABLA PARTICIONADA
---- QUE SE DIVIDE EN VARIAS PARTES.
---- VAMOS A FUSIONAR EL A�O 2017 CON EL A�O 2018


ALTER PARTITION FUNCTION FN_altayh ()
 MERGE RANGE ('2017-01-01'); 
 GO

SELECT *,$Partition.FN_altayh(fecha_alta) 
FROM altayh
GO



------------------ SWITCH-----------------

--- EL COMANDO SWITCH EN PARTICIONES SE UTILIZA PARA MOVER UNA PARTICI�N 
--- DE UNA TABLA A OTRA TABLA, O PARA CAMBIAR LA POSICI�N DE UNA PARTICI�N DENTRO DE LA MISMA TABLA.


SELECT *,$Partition.FN_altayh(fecha_alta) 
FROM altayh
GO




-- PRIMERO CREAMOS LA NUEVA TABLA A DONDE PODEMOS MOVER LOS DATOS DE LA PRIMERA PARTICI�N


CREATE TABLE altayh_nuevo
( id_alta int identity (1,1), 
nombre varchar(20), 
apellido varchar (20), 
fecha_alta datetime ) 
ON FG_Archivo
GO

-- UTILIZAMOS EL SWITCH PARA PASAR LOS DATOS 


ALTER TABLE altayh 
	SWITCH Partition 1 to altayh_nuevo
GO

--COMPROBAMOS QUE LA PARTICION DESAPARECI� 

SELECT *,$Partition.FN_altayh(fecha_alta) 
FROM altayh
GO




-- Y QUE SE FUE PARA LA NUEVA TABLA

SELECT *,$Partition.FN_altayh(fecha_alta) 
FROM altayh_nuevo
GO

--id_alta	nombre	apellido	fecha_alta	(Sin nombre de columna)
--2	Juan	Mart�nez	2018-02-05 00:00:00.000	2
--3	Sof�a	Ramos	2018-12-27 00:00:00.000	2
--6	Luc�a	Romero	2019-11-19 00:00:00.000	2
--7	Tom�s	Castillo	2018-04-09 00:00:00.000	2
--8	Gabriela	L�pez	2019-07-29 00:00:00.000	2
--10	Valentina	Garc�a	2018-06-06 00:00:00.000	2
--11	Nicol�s	Fern�ndez	2019-04-15 00:00:00.000	2
--12	Isabella	Hern�ndez	2018-12-30 00:00:00.000	2
--13	Emilio	V�zquez	2018-08-08 00:00:00.000	2
--14	Renata	Jim�nez	2018-02-22 00:00:00.000	2
--15	Joaqu�n	P�rez	2018-09-05 00:00:00.000	2
--16	Camila	�lvarez	2018-01-24 00:00:00.000	2




--------------TRUNCATE----------------------
-- ELIMINA UNA PARTICI�N


TRUNCATE TABLE altayh 
	WITH (PARTITIONS (3));
go

--COMPROBAMOS

SELECT *,$Partition.FN_altayh(fecha_alta) 
FROM altayh
GO

