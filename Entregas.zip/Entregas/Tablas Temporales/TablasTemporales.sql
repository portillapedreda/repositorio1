-----------TABLAS TEMPORALES-------------



USE master 
go
DROP DATABASE IF EXISTS YHtemporal 
GO
CREATE DATABASE [YHtemporal] 
	ON PRIMARY ( NAME = 'YHtemporal', 
	FILENAME = 'C:\datos\YHtemporal_Fijo.mdf' , 
	SIZE = 15360KB , MAXSIZE = UNLIMITED, FILEGROWTH = 0) 
	LOG ON ( NAME = 'YHtemporal_log', 
	FILENAME = 'C:\datos\YHtemporal_log.ldf' , 
	SIZE = 10176KB , MAXSIZE = 2048GB , FILEGROWTH = 10%) 
GO


USE YHtemporal
GO
DROP TABLE IF EXISTS pagos
GO
create table pagos 
	(   id_pago int identity(1,1) Primary Key Clustered,  
		importe money, ---------------------------------HASTA AQUI ES UNA TABLA NORMAL

	SysStartTime datetime2 generated always as row start not null,--TIEMPO EN QUE SE CREA LA FILA
	SysEndTime datetime2 generated always as row end not null, -----TIEMPO HASTA QUE ES VALIDA LA FILA
	period for System_time (SysStartTime,SysEndTime) ) -------------AQUI ACABA LA FUCI�N
	with (System_Versioning = ON (History_Table = dbo.pagos_historico)---PARA CONVERTIR LA TABLA NORMAL EN TABLA TEMPORAL PONEMOS EL "ON" Y LE DAMOS UN NOMBRE A LA TABLA
	) 
go


--PREGUNTAMOS QUE TIENEN LAS TABLAS(ESTAN VACIAS POR AHORA)

SELECT * FROM dbo.pagos
GO
SELECT * FROM dbo.pagos_historico
GO


--INSERTAMOS REGISTROS 

insert into pagos (importe) 
values ('1220'), 
	  ('2560'), 
	  ('1456'), 
	  ('1600'), 
	  ('890') 
GO 




--DISPLAYAMOS CON UN "PRINT" LAS FECHAS UNIVERSALES

PRINT GETUTCDATE()
GO

--Mar 16 2023 10:29AM

SELECT * FROM [dbo].[pagos]
GO

--1	1220,00	2023-03-16 10:18:29.4706125	9999-12-31 23:59:59.9999999
--2	2560,00	2023-03-16 10:18:29.4706125	9999-12-31 23:59:59.9999999
--3	1456,00	2023-03-16 10:18:29.4706125	9999-12-31 23:59:59.9999999
--4	1600,00	2023-03-16 10:18:29.4706125	9999-12-31 23:59:59.9999999
--5	890,00	2023-03-16 10:18:29.4706125	9999-12-31 23:59:59.9999999
                                                                                          

SELECT * FROM [dbo].[pagos_historico] ---APARECE VACIA PORQUE NO HUBO MOVIMIENTOS
GO

-- id_pago	importe	SysStartTime	SysEndTime



---EMPEZAMOS A HACER CAMBIOS

update pagos 
	set importe = '2463'
	where importe = '890'
GO


SELECT * FROM [dbo].[pagos]
GO

--1	1220,00	2023-03-16 10:18:29.4706125	9999-12-31 23:59:59.9999999
--2	2560,00	2023-03-16 10:18:29.4706125	9999-12-31 23:59:59.9999999
--3	1456,00	2023-03-16 10:18:29.4706125	9999-12-31 23:59:59.9999999
--4	1600,00	2023-03-16 10:18:29.4706125	9999-12-31 23:59:59.9999999
--5	2463,00	2023-03-16 10:36:01.3452157	9999-12-31 23:59:59.9999999

SELECT * FROM [dbo].[pagos_historico]
GO

--5	890,00	2023-03-16 10:18:29.4706125	2023-03-16 10:36:01.3452157



----OTRA ACTUALIZACI�N

update pagos 
	set importe = '1990'
	where importe = '1456'
GO


SELECT * FROM [dbo].[pagos]
GO

--1	1220,00	2023-03-16 10:18:29.4706125	9999-12-31 23:59:59.9999999
--2	2560,00	2023-03-16 10:18:29.4706125	9999-12-31 23:59:59.9999999
--3	1990,00	2023-03-16 10:38:06.7205041	9999-12-31 23:59:59.9999999
--4	1600,00	2023-03-16 10:18:29.4706125	9999-12-31 23:59:59.9999999
--5	2463,00	2023-03-16 10:36:01.3452157	9999-12-31 23:59:59.9999999

SELECT * FROM [dbo].[pagos_historico]
GO

--id_pago	importe  	SysStartTime            	SysEndTime
--5     	890,00  	2023-03-16 10:18:29.4706125	2023-03-16 10:36:01.3452157
--3	        1456,00  	2023-03-16 10:18:29.4706125	2023-03-16 10:38:06.7205041

-- VOY A ACTUALIZAR DE NUEVO EL �LTIMO VALOR

update pagos 
	set importe = '1999'
	where importe = '1990'
GO


SELECT * FROM [dbo].[pagos]
GO

--3	1999,00	2023-03-16 10:40:21.4080190	9999-12-31 23:59:59.9999999

SELECT * FROM [dbo].[pagos_historico]
GO

--  5	890,00	2023-03-16 10:18:29.4706125	2023-03-16 10:36:01.3452157
--  3	1456,00	2023-03-16 10:18:29.4706125	2023-03-16 10:38:06.7205041
--  3	1990,00	2023-03-16 10:38:06.7205041	2023-03-16 10:40:21.4080190   AL SUFRIR DOS UPDATES LA FECHA DE CREACI�N CAMBIA






--BORRAMOS UNA ENTRADA

delete from pagos 
	where importe='1999'
GO


SELECT * FROM [dbo].[pagos]
GO

--id_pago	importe	SysStartTime	SysEndTime
--1	1220,00	2023-03-16 10:18:29.4706125	9999-12-31 23:59:59.9999999
--2	2560,00	2023-03-16 10:18:29.4706125	9999-12-31 23:59:59.9999999  -- DESAPARECE LA TERCERA ENTRADA (id_pago 3)
--4	1600,00	2023-03-16 10:18:29.4706125	9999-12-31 23:59:59.9999999
--5	2463,00	2023-03-16 10:36:01.3452157	9999-12-31 23:59:59.9999999



SELECT * FROM [dbo].[pagos_historico]
GO
 
--5	890,00	2023-03-16 10:18:29.4706125	2023-03-16 10:36:01.3452157
--3	1456,00	2023-03-16 10:18:29.4706125	2023-03-16 10:38:06.7205041
--3	1990,00	2023-03-16 10:38:06.7205041	2023-03-16 10:40:21.4080190
--3	1999,00	2023-03-16 10:40:21.4080190	2023-03-16 10:42:00.6880687
					--CREACI�N							UPDATE(BORRADO)
					
--3	         2023-03-16 10:18:29.4706125		   2023-03-16 10:40:21.4080190



-----------INSERTAMOS DATOS


insert into pagos (importe)
	 values ('1999')
GO

SELECT * FROM [dbo].[pagos]
GO

-- Cambia la tabla a�adiendo el id 6 

--1	1220,00	2023-03-16 10:18:29.4706125	9999-12-31 23:59:59.9999999
--2	2560,00	2023-03-16 10:18:29.4706125	9999-12-31 23:59:59.9999999
--4	1600,00	2023-03-16 10:18:29.4706125	9999-12-31 23:59:59.9999999
--5	2463,00	2023-03-16 10:36:01.3452157	9999-12-31 23:59:59.9999999
--6	1999,00	2023-03-16 10:47:07.1496552	9999-12-31 23:59:59.9999999


SELECT * FROM [dbo].[pagos_historico]
GO

--No cambia nada

--5	890,00	2023-03-16 10:18:29.4706125	2023-03-16 10:36:01.3452157
--3	1456,00	2023-03-16 10:18:29.4706125	2023-03-16 10:38:06.7205041
--3	1990,00	2023-03-16 10:38:06.7205041	2023-03-16 10:40:21.4080190
--3	1999,00	2023-03-16 10:40:21.4080190	2023-03-16 10:42:00.6880687



-- BORRAMOS 

delete from pagos
	where importe='1999'
GO

SELECT * FROM [dbo].[pagos]
GO


--1	1220,00	2023-03-16 10:18:29.4706125	9999-12-31 23:59:59.9999999
--2	2560,00	2023-03-16 10:18:29.4706125	9999-12-31 23:59:59.9999999
--4	1600,00	2023-03-16 10:18:29.4706125	9999-12-31 23:59:59.9999999
--5	2463,00	2023-03-16 10:36:01.3452157	9999-12-31 23:59:59.9999999

SELECT * FROM [dbo].[pagos_historico]
GO

--5	890,00	2023-03-16 10:18:29.4706125	2023-03-16 10:36:01.3452157
--3	1456,00	2023-03-16 10:18:29.4706125	2023-03-16 10:38:06.7205041
--3	1990,00	2023-03-16 10:38:06.7205041	2023-03-16 10:40:21.4080190
--3	1999,00	2023-03-16 10:40:21.4080190	2023-03-16 10:42:00.6880687
--6	1999,00	2023-03-16 10:47:07.1496552	2023-03-16 10:49:09.7240922






-------------------------AN�LISIS BASADO EN TIEMPO (FOR SYSTEM_TIME)--------------------------



--Para realizar cualquier tipo de an�lisis basado en el tiempo, utiliza la nueva cl�usula FOR SYSTEM_TIME 
--con cuatro subcl�usulas espec�ficas para la temporalidad para consultar datos en las 
--tablas actuales e hist�ricas. Para obtener m�s informaci�n sobre estas cl�usulas, consulta "Tablas temporales" y "FROM (Transact-SQL)".


--AS OF <date_time>: Esta cl�usula permite consultar los datos que estaban vigentes 
--en una fecha y hora espec�ficas.


--FROM <start_date_time> TO <end_date_time>: Esta cl�usula permite consultar los datos que 
--estaban vigentes en un rango de tiempo espec�fico.


--BETWEEN <start_date_time> AND <end_date_time>: Esta cl�usula es similar a la anterior y permite consultar 
--los datos que estaban vigentes en un rango de tiempo espec�fico.


--CONTAINED IN (<start_date_time>, <end_date_time>): Recupera los datos que estaban en la tabla durante un 
--per�odo de tiempo espec�fico, contenido en el intervalo de tiempo especificado por la fecha y hora de inicio
--y la fecha y hora de finalizaci�n.

--ALL Recupera todos los datos de la tabla, tanto actuales como hist�ricos.




				---PROBAMOS CON EL "ALL" PARA VER TODAS LAS MODIFICACIONES DE LA TABLA


select * 
from dbo.pagos   ---CONSULTAMOS LA TABLA REAL
for system_time all		 ---APARECEN TODOS LOS MOVIMIENTOS	
go

--1	1220,00	2023-03-16 10:18:29.4706125	9999-12-31 23:59:59.9999999
--2	2560,00	2023-03-16 10:18:29.4706125	9999-12-31 23:59:59.9999999
--4	1600,00	2023-03-16 10:18:29.4706125	9999-12-31 23:59:59.9999999
--5	2463,00	2023-03-16 10:36:01.3452157	9999-12-31 23:59:59.9999999
--5	890,00	2023-03-16 10:18:29.4706125	2023-03-16 10:36:01.3452157
--3	1456,00	2023-03-16 10:18:29.4706125	2023-03-16 10:38:06.7205041
--3	1990,00	2023-03-16 10:38:06.7205041	2023-03-16 10:40:21.4080190
--3	1999,00	2023-03-16 10:40:21.4080190	2023-03-16 10:42:00.6880687
--6	1999,00	2023-03-16 10:47:07.1496552	2023-03-16 10:49:09.7240922

select * 
from [dbo].[pagos_historico]   --NO FUNCIONA SOBRE LA TABLA TEMPORAL
for system_time all 
go

--Mens. 13544, Nivel 16, Estado 2, L�nea 293
--La cl�usula FOR SYSTEM_TIME temporal solo se puede usar en tablas con versiones del sistema. 'YHtemporal.dbo.pagos_historico' no es una con versiones del sistema.






-----ESTE ES EL PREDICADO MAS UTILIZADO "AS OF"
---- Con �for system_time as of� vemos el estado de la tabla en un determinado punto en el tiempo.



select * 
from dbo.pagos 
for system_time as of '2023-03-16 11:45:30' 
go

--1	1220,00	2023-03-16 10:18:29.4706125	9999-12-31 23:59:59.9999999
--2	2560,00	2023-03-16 10:18:29.4706125	9999-12-31 23:59:59.9999999
--4	1600,00	2023-03-16 10:18:29.4706125	9999-12-31 23:59:59.9999999
--5	2463,00	2023-03-16 10:36:01.3452157	9999-12-31 23:59:59.9999999

--AQUI ORDENAMOS  

select id_pago, importe, SysStartTime
from dbo.pagos
for system_time as of '2023-03-16 11:45:30' 
WHERE id_pago = '2'
ORDER BY 3
go

-- 2	2560,00	2023-03-16 10:18:29.4706125



---- Con �for system_time from �fecha� to �fecha�� vemos los cambios sufridos en la tabla en un rango de fechas


select * 
from pagos 
for system_time from '2023-02-22 13:28:30' to '2023-03-16 11:45:30' 
WHERE importe = '2560'
go


--2	2560,00	2023-03-16 10:18:29.4706125	9999-12-31 23:59:59.9999999




--BETWEEN    Recupera los datos que estaban en la tabla durante un per�odo de tiempo espec�fico, 
--comprendido entre la fecha y hora de inicio y la fecha y hora de finalizaci�n especificadas.


select * 
from pagos 
for system_time between '2023-02-22 13:28:30' and '2023-03-16 11:45:30' 
WHERE importe = '2560'
go

--2	2560,00	2023-03-16 10:18:29.4706125	9999-12-31 23:59:59.9999999



-- Con �CONTAINED IN� se ven los registros que se introdujeron entre las una fecha  
-- 

select * 
from pagos 
for system_time contained in ('2023-02-22 13:28:30' , '2023-03-16 11:45:30')
GO

--5	890,00	2023-03-16 10:18:29.4706125	2023-03-16 10:36:01.3452157
--3	1456,00	2023-03-16 10:18:29.4706125	2023-03-16 10:38:06.7205041
--3	1990,00	2023-03-16 10:38:06.7205041	2023-03-16 10:40:21.4080190
--3	1999,00	2023-03-16 10:40:21.4080190	2023-03-16 10:42:00.6880687
--6	1999,00	2023-03-16 10:47:07.1496552	2023-03-16 10:49:09.7240922



--  DE CLASE -- DE CLASE -- DE CLASE -- DE CLASE -- DE CLASE -- DE CLASE -- DE CLASE -- DE CLASE -- DE CLASE -- DE CLASE --
--  DE CLASE -- DE CLASE -- DE CLASE -- DE CLASE -- DE CLASE -- DE CLASE -- DE CLASE -- DE CLASE -- DE CLASE -- DE CLASE --


----------------------------------------HACEMOS NUEVAS INSERCIONES DIA DIFERENTE----------------------



---EMPEZAMOS A HACER CAMBIOS

update reserva_plaza 
	set num_reservas = 7
	where curso = 'curso1'
GO


SELECT * FROM [dbo].[reserva_plaza]
GO

--curso1	7	2023-01-19 17:19:48.3855846	9999-12-31 23:59:59.9999999

SELECT * FROM [dbo].[reserva_plaza_historico]
GO

--curso1	2	2023-01-16 19:23:52.3940202	2023-01-16 19:33:30.1266404
--curso2	1	2023-01-16 19:23:52.3940202	2023-01-16 19:39:01.9976527
--curso2	9	2023-01-16 19:39:01.9976527	2023-01-16 19:42:20.5803266
--curso5	6	2023-01-16 19:23:52.3940202	2023-01-16 19:45:09.4382485
--curso6	13	2023-01-16 19:48:45.6962522	2023-01-16 19:50:12.7753710
--curso1	7	2023-01-16 19:33:30.1266404	2023-01-16 20:07:04.1162975
--curso1	11	2023-01-16 20:07:04.1162975	2023-01-19 17:19:48.3855846  Aqu� se ve el cambio de dia


--Hacemos otro update

update reserva_plaza 
	set num_reservas = 42
	where curso = 'curso2'
GO


SELECT * FROM [dbo].[reserva_plaza]
GO

--curso2	42	2023-01-19 17:26:33.3908455	9999-12-31 23:59:59.9999999

SELECT * FROM [dbo].[reserva_plaza_historico]
GO

--curso1	2	2023-01-16 19:23:52.3940202	2023-01-16 19:33:30.1266404
--curso2	1	2023-01-16 19:23:52.3940202	2023-01-16 19:39:01.9976527
--curso2	9	2023-01-16 19:39:01.9976527	2023-01-16 19:42:20.5803266
--curso5	6	2023-01-16 19:23:52.3940202	2023-01-16 19:45:09.4382485
--curso6	13	2023-01-16 19:48:45.6962522	2023-01-16 19:50:12.7753710
--curso1	7	2023-01-16 19:33:30.1266404	2023-01-16 20:07:04.1162975
--curso1	11	2023-01-16 20:07:04.1162975	2023-01-19 17:19:48.3855846
--curso2	12	2023-01-16 19:42:20.5803266	2023-01-19 17:26:33.3908455



----------------PROBAMOS PRIMERO CON EL ALL

select * 
from dbo.reserva_plaza   ---CONSULTAMOS LA TABLA REAL
for system_time all		 ---APARECEN TODOS LOS MOVIMIENTOS	
go

--curso1	7	2023-01-19 17:19:48.3855846	9999-12-31 23:59:59.9999999
--curso2	42	2023-01-19 17:26:33.3908455	9999-12-31 23:59:59.9999999
--curso3	4	2023-01-16 19:23:52.3940202	9999-12-31 23:59:59.9999999
--curso4	2	2023-01-16 19:23:52.3940202	9999-12-31 23:59:59.9999999
--curso1	2	2023-01-16 19:23:52.3940202	2023-01-16 19:33:30.1266404
--curso2	1	2023-01-16 19:23:52.3940202	2023-01-16 19:39:01.9976527
--curso2	9	2023-01-16 19:39:01.9976527	2023-01-16 19:42:20.5803266
--curso5	6	2023-01-16 19:23:52.3940202	2023-01-16 19:45:09.4382485
--curso6	13	2023-01-16 19:48:45.6962522	2023-01-16 19:50:12.7753710
--curso1	7	2023-01-16 19:33:30.1266404	2023-01-16 20:07:04.1162975
--curso1	11	2023-01-16 20:07:04.1162975	2023-01-19 17:19:48.3855846
--curso2	12	2023-01-16 19:42:20.5803266	2023-01-19 17:26:33.3908455


select * 
from reserva_plaza 
for system_time from '2023-01-16 19:55:30' to '2023-01-19 19:59:30' 
WHERE CURSO = 'curso2'
go

--curso2	42	2023-01-19 17:26:33.3908455	9999-12-31 23:59:59.9999999
--curso2	12	2023-01-16 19:42:20.5803266	2023-01-19 17:26:33.3908455